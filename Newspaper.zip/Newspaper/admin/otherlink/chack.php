<?php
session_start();
include '../../db/db.php';
if(isset($_POST['submit'])){
 $email=$_POST['email'];
 $pass=md5($_POST['password']);

 $sql="SELECT * FROM admin";
 $query=mysqli_query($db,$sql);
 $data=mysqli_fetch_assoc($query);

 if($data['email']== $email){
 	if($data['password']==$pass){
 	$_SESSION['logstatus']=true;
 	header('location:../index.php');
 }else{
 	$_SESSION['logstatus']=false;
 	$_SESSION['message']="Your email or password not correct";
 	header('location:login.php');
 }
}else{
	$_SESSION['logstatus']=false;
	$_SESSION['message']='Your email or password not correct';
 	header('location:../login.php');
}
}

?>