<?php
session_start();
$_SESSION['logstatus']=false;
$_SESSION['message']='Logout successfilly!';
header('location:../login.php');
?>