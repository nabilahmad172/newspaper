<?php
include 'subCategory/showCategory.php';
include 'subCategory/view.php';
?>

<div class="span9">
					<div class="content">

						<div class="module">
							<div class="module-head">
								<h3>Forms</h3>
								<center><p style="margin-top: -20px; color: green;">
									<?php
									if(isset($_SESSION['message'])){
										echo $_SESSION['message'];
									}
									unset($_SESSION['message']);
									?>
								</p></center>
							</div>
							<div class="module-body">

								<ul class="nav nav-tabs" role="tablist">
									<li class="active"><a href="#home" role="tab" data-toggle="tab"> Add Sub category</a></li>
									<li><a href="#profile" role="tab" data-toggle="tab">View</a></li>
								</ul>

								<!-- Tab panes -->
								<div class="tab-content">
									<div class="tab-pane active" id="home">
									<form class="form-horizontal row-fluid" action="pages/subCategory/saveSubCat.php" method="post">
										<div class="control-group">
											<label class="control-label" for="basicinput"> category</label>
												<select class="controls" name="cateID" required="">
													<option>...select...</option>
													<?php
													while($data=mysqli_fetch_assoc($select)){
													?>
													<option value="<?php echo $data['id']?>"><?php echo $data['category']?></option>
													<?php }?>
												</select>
										</div>
										<div class="control-group">
											<label class="control-label" for="basicinput">Sub category</label>
											<div class="controls">
												<input type="text" name="Subcategory" id="basicinput" placeholder="Type something here..." class="span8" required="">
											</div>
										</div>
										<div class="control-group">
											<div class="controls">
												<button type="submit" name="submit" class="btn btn-defult">Submit Form</button>
											</div>
										</div>
									</form>
									</div>
									<div class="tab-pane" id="profile">
										<div class="span9">
									<div class="content">

						

									<div class="module">
										<div class="module-head">
											<h3>DataTables</h3>
										</div>
										<div class="module-body table">
											<table cellpadding="0" cellspacing="0" border="0" class="datatable-1 table table-bordered table-striped	 display" width="100%">
												<thead>
													<tr>
														<th>id</th>
														<th>Category Id</th>
														<th>Sub category</th>
														<th>Add time</th>
														<th>Action</th>
													</tr>
												</thead>
												<tbody>
													<?php
													while($data1=mysqli_fetch_assoc($show)){
													?>
													<tr class="odd gradeX">
														<td><?php echo $data1['id']?></td>
														<td><?php echo $data1['category']?></td>
														<td><?php echo $data1['sub_category']?></td>
														<td><?php echo $data1['add_time']?></td>
															 
														<td>
													<?php 
													if($data1['status']==1){
													?>
												<a href="pages/subCategory/status.php?id=<?php echo $data1['id']?>&&status=inactive" class="btn btn-defult">Active</a>

												<?php }else{?>
												<a href="pages/subCategory/status.php?id=<?php echo $data1['id']?>&&status=active" class="btn btn-danger">Inactive</a>
												<?php }?>
												<a href="#exampleModal" data-toggle="modal" class="btn btn-defult" onclick="modal('pages/editSubCat.php?id=<?php echo $data1['id'];?>')">Edit</a>
												<a href="pages/subCategory/delete.php?id=<?php echo $data1['id'];?>" class="btn btn-defult">Delete</a>
														</td>
													</tr>
													<?php }?>
												</tbody>
											
											</table>
										</div>
									</div><!--/.module-->

					<br />
						
					</div><!--/.content-->
				</div>
									</div>
									
								</div>

							<br />

									
							</div>
						</div>

						
						
					</div><!--/.content-->
				</div>