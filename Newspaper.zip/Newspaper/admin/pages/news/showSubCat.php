<?php
include '../../../db/db.php';
$id=$_POST['id'];

$sqli="SELECT * FROM sub_category WHERE cat_id=$id";
$query=mysqli_query($db,$sqli);
?>

<?php
while ($data2=mysqli_fetch_assoc($query)) {
?>
<option value="<?php echo $data2['id'];?>"><?php echo $data2['sub_category'];?></option>
<?php }?>