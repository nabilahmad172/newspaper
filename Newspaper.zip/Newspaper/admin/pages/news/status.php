<?php
session_start();
include '../../../db/db.php';
 $id=$_GET['id'];
 $status=$_GET['status'];
 if($status=='inactive'){
 	$sql="UPDATE news SET status=0 WHERE id=$id";
 	$up=mysqli_query($db,$sql);
 	if($up > 0){
 		$_SESSION['message']='Data update successfully';
 		header('location:../../?route=pages/addnews');
 	}else{
 		$_SESSION['message']='Data update not successfully';
 		header('location:../../?route=pages/addnews');
 	}
 }

 if($status=='active'){
 	$sql="UPDATE news SET status=1 WHERE id=$id";
 	$up=mysqli_query($db,$sql);
 	if($up > 0){
 		$_SESSION['message']='Data update successfully';
 		header('location:../../?route=pages/addnews');
 	}else{
 		$_SESSION['message']='Data update not successfully';
 		header('location:../../?route=pages/addnews');
 	}
 }
?>