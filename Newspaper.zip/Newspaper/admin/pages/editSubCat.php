	<?php
	include 'subCategory/getSubcat.php';
	?>
	<form class="form-horizontal row-fluid" action="pages/subCategory/updateSubCat.php" method="post">
			
			<div class="control-group">
				<label class="control-label" for="basicinput">Sub category</label>
				<div class="controls">
					<input type="text" name="Subcategory" value="<?php echo $fetch['sub_category']?>" id="basicinput" placeholder="Type something here..." class="span8" required="">
					<input type="hidden" name="id" value="<?php echo $fetch['id']?>">
				</div>
			</div>
			<div class="control-group">
				<div class="controls">
					<button type="submit" name="submit" class="btn btn-defult">Submit Form</button>
				</div>
			</div>
		</form>