<?php
session_start();
include '../../../db/db.php';
if(isset($_POST['submit'])){
	$title=$_POST['title'];
	$shortblog=$_POST['sblog'];
	$largblog=$_POST['lblog'];
	$name=$_POST['name'];
	$imageName=$_FILES['image']['name'];
	$imageType=$_FILES['image']['type'];

	if($imageType != 'image/jpeg' && $imageType != 'image/jpg' && $imageType != 'image/png'){
				$_SESSION['message']='Failed! not match image type. jpeg jpg png';
				header('location:../../?route=pages/editiorial');
	}else{
		$path="../../../poster/$imageName";
		$up=move_uploaded_file($_FILES['image']['tmp_name'], $path);
		if($up > 0){
			
		$sql="INSERT INTO Editorial (title, short_blog, larg_blog, name, image) VALUES ('$title','$shortblog','$largblog','$name','$imageName')";
		$query=mysqli_query($db,$sql);
			if($query > 0){
				$_SESSION['message']='Data insert';
				header('location:../../?route=pages/editiorial');
			}else{
				$_SESSION['message']='Data not inserted';
				header('location:../../?route=pages/editiorial');
			}
		}
	}
}
?>