<?php
session_start();
include '../../../db/db.php';
$id=$_GET['id'];
$sql="DELETE FROM editorial WHERE id=$id";
$query=mysqli_query($db,$sql);
if($query > 0){
	$_SESSION['message']='Data delete!';
	header('location:../../?route=pages/editiorial');
}else{
	$_SESSION['message']='Data not deleted!';
	header('location:../../?route=pages/editiorial');
}
?>