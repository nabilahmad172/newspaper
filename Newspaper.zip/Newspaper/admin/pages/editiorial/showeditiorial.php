<?php 
include '../db/db.php';
$sql="SELECT * FROM editorial";
$query=mysqli_query($db,$sql);
 ?>