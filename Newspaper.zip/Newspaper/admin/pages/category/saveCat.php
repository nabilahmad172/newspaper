<?php
session_start();
include '../../../db/db.php';
if(isset($_POST['submit'])){
	$cat=$_POST['category'];

	
	$sql="INSERT INTO category( category, status) VALUES ('$cat',1)";

	$insert=mysqli_query($db,$sql);
	if($insert > 0){
		$_SESSION['message']='Data add successfuly';
		header("location:../../?route=pages/category");
	}else{
		$_SESSION['message']='Data add unsuccessfuly';
		header("location:../../?route=pages/category");
	}

}

?>