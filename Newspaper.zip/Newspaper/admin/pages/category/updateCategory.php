<?php
session_start();
include '../../../db/db.php';

if(isset($_POST['submit'])){
	$id=$_POST['id'];
	$category=$_POST['category'];

	$sql="UPDATE `category` SET category='$category' WHERE id=$id";
	$update=mysqli_query($db,$sql);
	if($update > 0){
		$_SESSION['message']='Data update Successful!';
		header('location:../../?route=pages/category');
	}else{
		$_SESSION['message']='Data not update Successful!';
		header('location:../../?route=pages/category');
	}
}

?>