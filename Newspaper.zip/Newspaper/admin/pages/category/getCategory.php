<?php
include '../../db/db.php';
$id=$_GET['id'];
$sql="SELECT * FROM category WHERE id=$id";
$get=mysqli_query($db,$sql);
$fetch=mysqli_fetch_assoc($get);

?>