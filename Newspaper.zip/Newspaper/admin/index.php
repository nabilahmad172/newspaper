﻿<?php 
session_start();
if(isset($_SESSION['logstatus'])){
  if($_SESSION['logstatus']==true){
?>
<!DOCTYPE html>
<html lang="utf-8">
<head>
    <head>
      <link rel="icon" href="../admin.png" type="image/x-icon" />
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Admin Panel</title>
        <link type="text/css" href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <link type="text/css" href="bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet">
        <link type="text/css" href="css/theme.css" rel="stylesheet">
        <link type="text/css" href="images/icons/css/font-awesome.css" rel="stylesheet">
        <link type="text/css" href='http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600'
            rel='stylesheet'>
    </head>
    <body>
        <?php include '_include/navbar.php';?>
        <!-- /navbar -->
        <div class="wrapper">
            <div class="container">
                <div class="row">
                   <?php include '_include/sidebar.php';?>
                    <!--/.span3-->
                   <?php

                   if(isset($_GET['route'])){

                    $page=$_GET['route'].".php";

                    if(file_exists($page)){
                        include $page;
                    }else{
                        echo "Page not found";
                    }
                   }else{
                    include '_include/mainContent.php';
                   }
                    
                    ?>
                  

                        

                    <!--/.span9-->
                </div>
            </div>
            <!--/.container-->
        </div>

        <!-- Modal -->
               <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Edit page</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  <div class="modal-body" id="modal-body">
                    ...
                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    
                  </div>
                </div>
              </div>
            </div>

                
 <script type="text/javascript">
            function modal(route){
                $("#modal-body").load(route);
            }
             </script>

                <!-- end modal -->
        <!--/.wrapper-->
        <div class="footer">
            <div class="container">
                <b class="copyright">&copy;  </b>All rights reserved.
            </div>
        </div>
        <script src="scripts/jquery-1.9.1.min.js" type="text/javascript"></script>
        <script src="scripts/jquery-ui-1.10.1.custom.min.js" type="text/javascript"></script>
        <script src="bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
        <script src="scripts/flot/jquery.flot.js" type="text/javascript"></script>
        <script src="scripts/flot/jquery.flot.resize.js" type="text/javascript"></script>
        <script src="scripts/datatables/jquery.dataTables.js" type="text/javascript"></script>
        <script src="scripts/common.js" type="text/javascript"></script>
      
    </body>
    <?php
  
    }else{
      $_SESSION['message']='Please login first';
      header('location:login.php');
    }
}else{
     $_SESSION['message']='Please login first';
      header('location:login.php');
    }
    ?>
  
