<?php
include 'display/breakingnews.php';
?>

<section id="first-section">
		<div class="container top-header-1">
			
				<div class="col-sm-5">
				    <div class="time">
						<span>ঢাকা, শনিবার, ১২ জ্যৈষ্ঠ ১৪২৫, ২৬ মে ২০১৮8</span>
					</div>
				</div>
				<div class="col-sm-3">
					<div class="media-icon">
						<a href="https://www.facebook.com/" target="_blank" title="facebook"><i class="fa fa-facebook-official fa-2x"></i></a>
						<a href="https://twitter.com/" target="_blank"><i class="fa fa-twitter fa-2x" title="twitter"></i></a>
						<a href="https://plus.google.com/" target="_blank"><i class="fa fa-google-plus fa-2x" title="google plus"></i></a>
						<a href="https://bd.linkedin.com/" target="_blank" title="linkedin"><i class="fa fa-linkedin-square fa-2x"></i></a>
						<a href="https://www.youtube.com/" target="_blank" title="youtube"><i class="fa fa-youtube fa-2x"></i></a>
						
					</div>
				</div>
				<div class="col-sm-4">
					<div class="language">
						<a href="" class="btn btn-success">Engish</a>
					</div>
				</div>
			
		</div>
	</section>

	<section id="secound-sesction">
		<div class="container top-header-2">
			<div class="col-sm-5">
				<div class="logo">
					<a href="../Newspaper"><img src="img/logo/logo.png"></a>
				</div>
			</div>
		</div>
	</section>

	<section id="third-sesction">
		<div class="container top-header-3">
			<div class="headding">
				<div class="col-sm-1 lastnews">
					<span>ব্রেকিং নিউজ :</span>
				</div>
				<div class="col-sm-8">
					<div style="padding:  15px;">
						<marquee behavior="scroll" direction="left" onmouseover="this.stop();" onmouseout="this.start();">
							<?php
							while($data=mysqli_fetch_assoc($q)){
							?>
							<a href="?route=pages/details&&id=<?php echo $data['id']?>" style="text-decoration: none; font-size:15px; padding: 15px;"><?php echo $data['news_title']?></a>
							<?php }?>
						</marquee>
					</div>
					
				</div>
				<div class="col-sm-3 search">
					<input type="text" name="search" placeholder="সার্চ">
					<button><i class="glyphicon glyphicon-search"></i></button>
				</div>
				
			</div>
		</div>
	</section>