<section>
	<div class="container" style="margin-top: 5px;background-color: #222222;">
		<div class="row">
			<div class="col-sm-12">
				<div class="col-sm-3" style="margin-top: 50px;">
					<img src="img/logo/logo.png">
				</div>
				<div class="col-sm-3" style="margin-top: 50px;">
					<address style="color: #fff;">
						সম্পাদক : ইয়াসির আরাফাত

					</address>
				</div>
				<div class="col-sm-3" style="margin-top: 50px;">
					<address style="color: #fff;">
						যোগাযোগ <br>
						১ আর. কে মিশন রোড, (মানিক মিয়া ফাউন্ডেশন ভবন) , ঢাকা-১২০৩।
						ফোন: ৫৭১৬৫২৬১-৯
					</address>
				</div>
				<div class="col-sm-3" style="padding: 62px;">
				
						<a href="https://www.facebook.com/" target="_blank" title="facebook"><i class="fa fa-facebook-official fa-2x"></i></a>
						<a href="https://twitter.com/" target="_blank"><i class="fa fa-twitter fa-2x" title="twitter"></i></a>
						<a href="https://plus.google.com/" target="_blank"><i class="fa fa-google-plus fa-2x" title="google plus"></i></a>
						<a href="https://bd.linkedin.com/" target="_blank" title="linkedin"><i class="fa fa-linkedin-square fa-2x"></i></a>
						<a href="https://www.youtube.com/" target="_blank" title="youtube"><i class="fa fa-youtube fa-2x"></i></a>
						
					
				</div>
			</div>
			<div style="margin-top: 3px; background-color: #000; color: #fff; text-align: center;">
				<p>এই ওয়েবসাইটের কোনো লেখা বা ছবি অনুমতি ছাড়া নকল করা বা অন্য কোথাও প্রকাশ করা সম্পূর্ণ বেআইনি। সকল স্বত্ব www.ahl.com কর্তৃক সংরক্ষিত</p>
			</div>
		</div>
	</div>
</section>