

<section>
	<div class="container">
		<div class="page404">
			<h1>404</h1>
			<h3>Page not found</h3>
		</div>
	</div>
</section>