<?php
include 'display/menu.php';
?>

<section id="menu">
	<div class="container menu1">
	   <nav class="navbar navbar-default">
		  <div class="container-fluid">
		    <!-- Brand and toggle get grouped for better mobile display -->
		    <div class="navbar-header">
		      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
		        <span class="sr-only">Toggle navigation</span>
		        <span class="icon-bar"></span>
		        <span class="icon-bar"></span>
		        <span class="icon-bar"></span>
		      </button>
		      
		    </div>

		    <!-- Collect the nav links, forms, and other content for toggling -->
		    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
		      <ul class="nav navbar-nav">
		      	<li><a href=""><i class="fa fa-home" aria-hidden="true"></i></a></li>
		        <?php
		        while($data=mysqli_fetch_assoc($select)){
		        ?>
		        <li class="dropdown">
		          <a href="" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><?php echo $data['category']?><span class="caret"></span></a>
		          <ul class="dropdown-menu">

		          	<?php
		          	while($data2=mysqli_fetch_assoc($select2)){
		          		if($data['id']==$data2['cat_id']){
		          	?>
		            <li><a href="?route=pages/menu&&id=<?php echo $data2['id']?>"><?php echo $data2['sub_category']?></a></li>
		            <?php }
		            	}
		            	mysqli_data_seek($select2,0);
		            ?>

		          </ul>
		        </li>
		        <?php }?>
		        
		      </ul>
		        
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>
  </div>
</section>