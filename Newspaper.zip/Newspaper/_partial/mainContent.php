
<?php
include 'display/midContentNews.php';
include 'display/atLastnews.php';
include 'display/todaynews.php';
include 'display/slideSideNews.php';
include 'display/catWisenews.php';
include 'display/slideNews.php';
include 'display/test.php';
include 'display/mostview.php';
include 'display/editiorial.php';




?>
<!-- fifth-sesction -->
<!-- slider -->
<section id="fifth-sesction">
	<div class="container">
		<div class="fifth-content">
		<div class="col-sm-6">
			<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
  <!-- Indicators -->
  <ol class="carousel-indicators">
  	<?php
  	  	$flag = 0;
  	  	$i=0;
  	while($slide=mysqli_fetch_assoc($slidequery)){
  	?>
    <li data-target="#carousel-example-generic" data-slide-to="<?php echo $i++; ?>" class=" <?php if($flag==0){ echo "active"; } ?>"></li>
   
    <?php 
  	  	$flag = 1; }?>
  </ol>

  <!-- Wrapper for slides -->
  <div class="carousel-inner" role="listbox">
	<?php
  	  	mysqli_data_seek($slidequery,0);
  	  	$flag = 0;
  		while($slide=mysqli_fetch_assoc($slidequery)){
  		?>

    <div class="item <?php if($flag==0){ echo "active"; } ?>">
    	<a href="?route=pages/details&&id=<?php echo $slide['id']?>">
      		<img src="poster/<?php echo $slide['poster']; ?>" alt="...">
  		</a>
      <div class="carousel-caption">
        <h4>
        	
        	<a href="?route=pages/details&&id=<?php echo $slide['id']?>" style="color: #fff; text-decoration: none;">
        		<?php echo $slide['news_title']?>
        	</a>
        		
        </h4>
      </div>
    </div>
  
    <?php $flag=1; } ?>
  

  </div>

  <!-- Controls -->
  <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
		</div>
		<div class="col-sm-4">
			<?php
			mysqli_data_seek($sel_SubCat,0);
			$a=0;
				while($subCat=mysqli_fetch_assoc($sel_SubCat)){
					$a++;
				while($subCatNews=mysqli_fetch_assoc($subNewsQuery[$a])){
			?>
			<div class="row DHmSpecial1">
				<div class="col-sm-5">
					<a href="?route=pages/details&&id=<?php echo $subCatNews['id']?>"><img src="poster/<?php echo $subCatNews['poster']?>" class="img-thumbnail"></a>
				</div>
				<div class="col-sm-7">
					<h4><a href="?route=pages/details&&id=<?php echo $subCatNews['id']?>" style="text-decoration: none;"><?php echo $subCatNews['news_title']?></a></h4>
				</div>
			</div>

			<?php }
				}
			?>
			
		</div>
		
			<!-- @@@@ -->
			<div class="col-sm-2">
				<div class="row">
					<div class="col-sm-12 HmAnnouncement2">
						<div class="panel panel-default">
							<a href=""><img src="img/editorial-new.jpg"></a>
							<div class="panel-body">
								<h4><a href="?route=pages/editiorialDetails&&id=<?php echo $fetch_editiorial['id']?>"><b><?php echo $fetch_editiorial['title']?></b></a></h4>
								<p>
									<?php echo $fetch_editiorial['short_blog']?>
								</p>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- @@@@ -->
		</div>
		
	</div>
	</div>
</section>
<!-- end slider -->
<!-- end fifth-sesction -->

<section>
	<div class="container DMarginBottom20">
		
			<div class="col-sm-8">
				<div class="row ">
					<div class="col-sm-12">
						<div class="row">
							<?php
							mysqli_data_seek($q,0);
							$a=0;
							while ($b=mysqli_fetch_assoc($q)) {
							$a++;
							while($abc=mysqli_fetch_assoc($viewnews[$a])){
							?>
							<div class="col-sm-4">
								<div>
									<a href="?route=pages/details&&id=<?php echo $abc['id']?>"><img src="poster/<?php echo $abc['poster']?>" class="img-thumbnail"></a>
								</div>
								<div>
									<span>
										<a href="?route=pages/details&&id=<?php echo $abc['id']?>" style="text-decoration: none;"><?php echo $abc['news_title']?></a>
									</span>
								</div>
							</div>
							<?php
						}
						mysqli_data_seek($viewnews[$a],1);
					}
							?>
						</div>
					</div>
				</div>
			</div>
		
		 <div class="col-sm-4">
			<ul class="nav nav-tabs" role="tablist">
				  <li class="active"><a href="#atlast" role="tab" data-toggle="tab">সর্বশেষ</a></li>
				  <li><a href="#profile" role="tab" data-toggle="tab">জনপ্রিয়</a></li>
				  <li><a href="#todaynews" role="tab" data-toggle="tab">আজকের খবর</a></li>
				</ul>

				<!-- Tab panes -->
				<div class="tab-content">
				  <div class="tab-pane active" id="atlast">
				  	<ul>
				  		<?php
				  		while ($atLast=mysqli_fetch_assoc($query_atlast)) {
				  		
				  		?>
				  		<li><a href=""><?php echo $atLast['news_title']?></a></li>
				  		<?php }?>

				  	</ul>
				  </div>
				  <div class="tab-pane" id="profile">
				  	<ul>
				  		<?php
				  		while($popular=mysqli_fetch_assoc($sql_query)){
				  		?>
				  		<li><a href="?route=pages/details&&id=<?php echo $popular['id']?>"><?php echo $popular['news_title']?></a></li>
				  		<?php }?>
				  		
				  	</ul>
				  </div>
				  <div class="tab-pane" id="todaynews">
				  	<ul>
				  		<?php
				  		while($todaynews=mysqli_fetch_assoc($todayquery)){
				  		?>
				  		<li><a href=""><?php echo $todaynews['news_title']?></a></li>
				  		<?php }?>
				  		
				  	</ul>
				  </div>
				 
				</div>
		</div> 
	</div>
</section>
<!-- add -->
<section>
	<div class="container" style="margin-top: 7px;">
		<div class="addpic">
			<img src="img/World_Cup_big.jpg" class="img-thumbnail">
			
		</div>
	</div>
</section>
<!-- end add -->
<!-- start -->
<section>
	<div class="container" style="margin-top: 7px;">
		<div class="row">
			<div class="col-sm-12" style="margin-bottom: 10px;">
				<?php
				mysqli_data_seek($cat_query,0);
				$i=0;
				while($aa=mysqli_fetch_assoc($cat_query)){
					$i++;
				?>
				<div class="col-sm-4">
					<div style="background-color: #1B59A4; text-align: center; color: #fff; font-size: 25px; border-radius: 2%;">
						<span><?php echo $aa['category']?></span>
					</div>
					<?php
					while($bb=mysqli_fetch_assoc($c[$i])){
					?>
					<div class="row" style="margin-top: 18px;">
						<div class="col-sm-3" style="margin-top: 8px; margin-bottom: 8px;">
							<a href="?route=pages/details&&id=<?php echo $bb['id']?>"><img src="poster/<?php echo $bb['poster']?>" class="img-thumbnail"></a>
						</div>
						<div class="col-sm-9" style="margin-top: 8px; margin-bottom: 8px; overflow: hidden;">
							<a href="?route=pages/details&&id=<?php echo $bb['id']?>" style="text-decoration: none;">
								<div>
									<span style="color: #232121;font-size: 18px;">
									<?php echo $bb['news_title']?>
								</span>
								</div>
								
							</a>
						</div>
					</div>
					<?php }?>
				</div>
				<?php }?>
				
			</div>
		</div>
	</div>
</section>
<!--  end-->