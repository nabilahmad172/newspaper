<?php
include 'db/db.php';
$id=$_GET['id'];
$sql="SELECT * FROM sub_category WHERE id=$id";
$query_sql=mysqli_query($db,$sql);
$fetch_sql=mysqli_fetch_assoc($query_sql);

?>