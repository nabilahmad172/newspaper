<?php
include 'db/db.php';
$id=$_GET['id'];
$sql="SELECT news.*,sub_category.sub_category FROM news LEFT JOIN sub_category ON news.sub_cat_id=sub_category.id WHERE news.sub_cat_id=$id AND news.status=1 ORDER BY news.id DESC LIMIT 8";
$query=mysqli_query($db,$sql);

?>