<?php
include 'db/db.php';

$id=$_GET['id'];
$sql="SELECT * FROM news WHERE id=$id AND status=1";
$query=mysqli_query($db,$sql);

$fetch=mysqli_fetch_assoc($query);

$view=$fetch['view']+1;

$sql_up="UPDATE news SET view=$view WHERE id=$id";
$sql_query=mysqli_query($db,$sql_up);
?>