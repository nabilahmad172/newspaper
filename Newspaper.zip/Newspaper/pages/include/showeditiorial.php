<?php
include 'db/db.php';
$id=$_GET['id'];
$sql="SELECT * FROM editorial WHERE id=$id";
$query=mysqli_query($db,$sql);
$feth_row=mysqli_fetch_assoc($query);
?>