<?php
include 'pages/include/subCat.php';
include 'pages/include/subCategorywise.php';
include 'pages/include/anothernews.php';
include 'pages/include/popular.php';
?>

<section>
	<div class="container">
		<div class="row">
			<div style="margin-top: 7px; margin-bottom: 0px; font-size: 20px; background-color: #F5F5F2;">
				<i class="fa fa-home"> /</i>
				<span>
					<?php echo $fetch_sql['sub_category']?>	
				</span>
			</div>
		</div>
	</div>
</section>

<section>
	<div class="container" style="margin-top: 7px;">
		<div class="row">
			<div class="col-sm-12">
				<div class="col-sm-6">
					<!-- slider -->
							<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
							<!-- Indicators -->
								<ol class="carousel-indicators">
								<?php
									$flag = 0;
									$i=0;
									while($slide=mysqli_fetch_assoc($query)){
								?>
									<li data-target="#carousel-example-generic" data-slide-to="<?php echo $i++; ?>" class=" <?php if($flag==0){ echo "active"; } ?>"></li>

								<?php 
									$flag = 1; }?>
								</ol>

							<!-- Wrapper for slides -->
							<div class="carousel-inner" role="listbox">
							<?php
							mysqli_data_seek($query,0);
							$flag = 0;
							while($slide=mysqli_fetch_assoc($query)){
							?>

							<div class="item <?php if($flag==0){ echo "active"; } ?>">
								<a href="?route=pages/details&&id=<?php echo $slide['id']?>">
								<img src="poster/<?php echo $slide['poster']; ?>" alt="...">
								</a>
								<div class="carousel-caption">
									<h4>

										<a href="?route=pages/details&&id=<?php echo $slide['id']?>" style="color: #fff; text-decoration: none;">
										<?php echo $slide['news_title']?>

										</a>

									</h4>
								</div>
							</div>
							<?php $flag=1; } ?>
							</div>

							<!-- Controls -->
							<a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
								<span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
								<span class="sr-only">Previous</span>
							</a>
							<a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
								<span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
								<span class="sr-only">Next</span>
							</a>
							</div>

					<!-- slider -->
					<!-- start -->
					<div class="row">
						<div style="background-color: #1B59A4; text-align: center; color: #fff; font-size: 32px; border-radius: 2%;padding: 3px; margin-bottom: 6px; margin-top: 5px;">
							<h3>এই বিভাগের সর্বশেষ</h3>
						</div>

							<div class="col-sm-12">
								<?php
								mysqli_data_seek($query,1);
								while($data=mysqli_fetch_assoc($query)){
								?>
								<div class="row" style="margin-bottom: 8px;">
									<div class="col-sm-3" style="float: left;">
									<img src="poster/<?php echo $data['poster']?>" class="img-thumbnail">
									</div>
									<div class="col-sm-9" style="float: right;">
										<a href="?route=pages/details&&id=<?php echo $data['id']?>" style="text-decoration: none;">
											<h5 style="font-size: 25px;"><?php echo $data['news_title']?></h5>
										</a>
										<p>
										<a href=""> Reade more...</a>
										</p>
									</div>
								</div>
								<?php }?>
							</div>
					</div>
					<!-- end -->
				
				</div>
			

				<div class="col-sm-3">
					<div style="background-color: #1B59A4; text-align: center; color: #fff; font-size: 32px; border-radius: 2%;padding: 5px; margin-bottom: 6px;">
						<h4>এই বিভাগের জনপ্রিয়</h4>
					</div>
					<?php
					while($data2=mysqli_fetch_assoc($sql_query)){
					?>
					<div>
						<img src="poster/<?php echo $data2['poster']?>" class="img-thumbnail">
						<a href="?route=pages/details&&id=<?php echo $data2['id']?>" style="font-size:17px;"><?php echo $data2['news_title']?></a>
					</div>
					<?php }?>
				</div>

					<div class="col-sm-3">
					<div style="background-color: #1B59A4; text-align: center; color: #fff; font-size: 32px; border-radius: 2%;padding: 5px; margin-bottom: 6px;">
						<h4>অন্য বিভাগের খবর</h4>
					</div>
					<?php
					mysqli_data_seek($sql_query,0);
					$a=0;
					while($fetchSub=mysqli_fetch_assoc($sql_query)){
						$a++;
					while($fetchNews=mysqli_fetch_assoc($sql_news_query[$a])){
					?>
					<div>
						<a href="?route=pages/details&&id=<?php echo $fetchNews['id']?>"><img src="poster/<?php echo $fetchNews['poster']?>" class="img-thumbnail"></a>
						<a href="?route=pages/details&&id=<?php echo $fetchNews['id']?>" style="font-size:17px; text-decoration: none;"><?php echo $fetchNews['news_title']?></a>
					</div>
					<?php
				}
			}
					?>
				</div>
				
			</div>
		</div>
			
	</div>
</section>


	