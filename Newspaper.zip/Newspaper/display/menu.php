<?php
include 'db/db.php';
$sql="SELECT * FROM category WHERE status=1";
$select=mysqli_query($db,$sql);

$sql2="SELECT * FROM sub_category WHERE status=1";
$select2=mysqli_query($db,$sql2);

?>