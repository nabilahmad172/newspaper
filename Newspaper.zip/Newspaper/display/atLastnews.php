<?php
include 'db/db.php';
$select_atlast="SELECT * FROM news WHERE status=1 ORDER BY id DESC";
$query_atlast=mysqli_query($db,$select_atlast);

?>