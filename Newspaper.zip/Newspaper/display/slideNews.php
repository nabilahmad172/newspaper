<?php
include 'db/db.php';

$sql="SELECT * FROM news WHERE status=1 ORDER BY id DESC LIMIT 8";
$slidequery=mysqli_query($db,$sql);
?>