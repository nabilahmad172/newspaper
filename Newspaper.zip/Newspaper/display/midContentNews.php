<?php
include 'db/db.php';
$select_cat="SELECT * FROM category WHERE status=1";
$cat_query=mysqli_query($db,$select_cat);
$a=0;
while($fetch=mysqli_fetch_assoc($cat_query)){
	$a++;
	$catID=$fetch['id'];
	$news="SELECT * FROM news WHERE cat_id=$catID AND status=1 ORDER BY id DESC LIMIT 1";
	$queryNews[$a]=mysqli_query($db,$news);

}
?>