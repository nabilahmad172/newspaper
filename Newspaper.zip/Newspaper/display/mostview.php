<?php
include 'db/db.php';
$sql="SELECT * FROM news ORDER BY view DESC ";
$sql_query=mysqli_query($db,$sql);
?>