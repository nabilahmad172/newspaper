<?php
include 'db/db.php';
$sql="SELECT * FROM sub_category WHERE status=1 LIMIT 4";
$sel_SubCat=mysqli_query($db,$sql);
$a=0;
while($fetch=mysqli_fetch_assoc($sel_SubCat)){
	$a++;
	$id=$fetch['id'];
	$subNews="SELECT * FROM news WHERE sub_cat_id=$id AND status=1 ORDER by id DESC LIMIT 1";
	$subNewsQuery[$a]=mysqli_query($db,$subNews);
}
?>