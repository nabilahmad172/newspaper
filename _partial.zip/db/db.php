<?php
$db=mysqli_connect("localhost","root","","newspaper") or die ("Database Not connect");
mysqli_set_charset($db,'utf8');
?>