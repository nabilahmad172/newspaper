<?php
include 'include/showAlldetails.php';
include 'include/popularnews.php';
?>

<section>
	<div class="container">
		<div class="row">
			<div style="margin-top: 7px; margin-bottom: 0px; font-size: 20px; background-color: #F5F5F2;">
				<i class="fa fa-home"> /</i>
				<span></span>
			</div>
		</div>
	</div>
</section>

<section>
	<div class="container">
		<div class="col-sm-12">
			<div class="col-sm-9">
				<div style="background-color: #F5F5F2;">
					<h2 style="padding: 16px 0px 0px 14px;"><?php echo $fetch['news_title']?></h2>
					<hr>
					<p style="padding: 0px 15px; font-size: 18px;"><?php echo $fetch['publisher']?>  : AHL.com</p>
					<p style="padding: 0px 15px;">প্রকাশ: <?php echo $fetch['add_time']?></p>
				</div>

				<div>
					<div>
						<img src="poster/<?php echo $fetch['poster']?>" style="width: 100%;">
					</div>
					<div style="padding: 10px; margin-bottom: 5px; border:1px solid #ccc;">
						<p style="font-size: 17px;">
							<?php echo $fetch['news_details']?>
						</p>
					</div>

				</div>
			</div>
			<div class="col-sm-3">
					<div style="background-color: #1B59A4; text-align: center; color: #fff; font-size: 32px; border-radius: 2%;padding: 5px; margin-bottom: 6px;">
						<h4> জনপ্রিয় খবর</h4>
					</div>
					<?php
					while($data=mysqli_fetch_assoc($sql_query)){
					?>
					<div>
						<img src="poster/<?php echo $data['poster']?>" class="img-thumbnail">
						<a href="" style="font-size:17px;"><?php echo $data['news_title']?></a>
					</div>
					<?php }?>
				</div>
	</div>
</section>