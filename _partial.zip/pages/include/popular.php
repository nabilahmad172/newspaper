<?php
include 'db/db.php';
$id=$_GET['id'];
$sql="SELECT * FROM news WHERE sub_cat_id=$id ORDER BY view DESC";
$sql_query=mysqli_query($db,$sql);

?>