<?php
include 'db/db.php';
//$id=$_GET['id'];
$sql="SELECT * FROM sub_category WHERE status=1";
$sql_query=mysqli_query($db,$sql);

$a=0;
while($fetch=mysqli_fetch_assoc($sql_query)){
	$a++;
	$Subid=$fetch['id'];
	$sql_news="SELECT * FROM news WHERE sub_cat_id=$Subid AND status=1 ORDER BY id DESC LIMIT 10";
	$sql_news_query[$a]=mysqli_query($db,$sql_news);
}
?>