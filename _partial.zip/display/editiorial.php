<?php
include 'db/db.php';
$sql="SELECT * FROM editorial ORDER BY id DESC LIMIT 1";
$query=mysqli_query($db,$sql);
$fetch_editiorial=mysqli_fetch_assoc($query);

?>