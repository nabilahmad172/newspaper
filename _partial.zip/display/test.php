<?php
include 'db/db.php';
$sql="SELECT * FROM sub_category WHERE status=1 LIMIT 9";
$q=mysqli_query($db,$sql);
$a=0;
while($fetch=mysqli_fetch_assoc($q)){
	$a++;
	$id=$fetch['id'];
	$n="SELECT * FROM news WHERE sub_cat_id=$id AND status=1 ORDER BY id DESC LIMIT 1";
	$viewnews[$a]=mysqli_query($db,$n);
}
?>