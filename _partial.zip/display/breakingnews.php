<?php
include 'db/db.php';
$sql2="SELECT * FROM news WHERE status=1 ORDER BY id DESC LIMIT 3";
$q=mysqli_query($db,$sql2);


?>