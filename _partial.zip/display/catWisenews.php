<?php
include 'db/db.php';
$sql="SELECT * FROM category WHERE status=1";
$cat_query=mysqli_query($db,$sql);
$a=0;
while($f=mysqli_fetch_assoc($cat_query)){
$a++;
$id=$f['id'];
$b="SELECT * FROM news WHERE cat_id=$id AND status=1 order by id desc";
$c[$a]=mysqli_query($db,$b);
}
?>