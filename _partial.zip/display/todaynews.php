<?php
include 'db/db.php';
$date=date("d-m-Y");


$today="SELECT * FROM news WHERE today='$date' ORDER BY id DESC";
$todayquery=mysqli_query($db,$today);


?>