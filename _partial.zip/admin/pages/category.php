<?php
include 'category/view.php';
?>
<div class="span9">
					<div class="content">

						<div class="module">
							<div class="module-head">
								<h3>Forms</h3>
								<center><p style="margin-top: -20px; color: green;">
									<?php
									if(isset($_SESSION['message'])){
										echo $_SESSION['message'];
									}
									unset($_SESSION['message']);
									?>
								</p></center>
							</div>
							<div class="module-body">

								<ul class="nav nav-tabs" role="tablist">
									<li class="active"><a href="#home" role="tab" data-toggle="tab">Add category</a></li>
									<li><a href="#profile" role="tab" data-toggle="tab">View Category</a></li>
									
								</ul>

								<!-- Tab panes -->
								<div class="tab-content">
									<div class="tab-pane active" id="home">
									<form class="form-horizontal row-fluid" action="pages/category/saveCat.php" method="post">
										<div class="control-group">
											<label class="control-label" for="basicinput">Add category</label>
											<div class="controls">
												<input type="text" name="category" id="basicinput" placeholder="Type something here..." class="span8" required="">
											</div>
										</div>
										<div class="control-group">
											<div class="controls">
												<button type="submit" name="submit" class="btn btn-defult">Submit Form</button>
											</div>
										</div>
									</form>
									</div>
									<div class="tab-pane" id="profile">
										<div class="module">
							<div class="module-head">
								<h3>Category DataTables</h3>
							</div>
							<div class="module-body table">
								<table cellpadding="0" cellspacing="0" border="0" class="datatable-1 table table-bordered table-striped	 display" width="100%">
									<thead>
										<tr>
											<th>ID</th>
											<th>Category</th>
											<th>Add time</th>
											<th>Action</th>
											

										</tr>
									</thead>
									<tbody>
										<?php 
										while($data=mysqli_fetch_assoc($select)){

										?>
										<tr class="gradeU">
											<td><?php echo $data['id']?></td>
											<td><?php echo $data['category']?></td>
											<td><?php echo $data['add_time']?></td>
											<td>
												<?php 
													if($data['status']==1){
												?>
												<a href="pages/category/status.php?id=<?php echo $data['id']?>&&status=inactive" class="btn btn-defult">Active</a>

												<?php }else{?>
												<a href="pages/category/status.php?id=<?php echo $data['id']?>&&status=active" class="btn btn-danger">Inactive</a>
												<?php }?>
												<a href="#exampleModal" data-toggle="modal" class="btn btn-defult" onclick="modal('pages/editCategory.php?id=<?php echo $data['id'];?>')">Edit</a>
												<a href="pages/category/delete.php?id=<?php echo $data['id'];?>" class="btn btn-defult">Delete</a>
											</td>
										</tr>
										<?php }?>
									</tbody>
									
								</table>
							</div>
						</div>
									</div>
									
								</div>

							<br />

									
							</div>
						</div>

						
						
					</div><!--/.content-->
				</div>