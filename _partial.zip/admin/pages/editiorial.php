<?php 
include 'editiorial/showeditiorial.php';
?>

<div class="span9">
					<div class="content">

						<div class="module">
							<div class="module-head">
								<h3>Forms</h3>
								<center><span>
									<?php 
										if(isset($_SESSION['message'])){
											echo $_SESSION['message'];
										}
										unset($_SESSION['message']);
									 ?>

								</span></center>
							</div>
							<div class="module-body">
								<ul class="nav nav-tabs" role="tablist">
									<li class="active"><a href="#home" role="tab" data-toggle="tab">Add category</a></li>
									<li><a href="#profile" role="tab" data-toggle="tab">View Category</a></li>
									
								</ul>
									
								<div class="tab-content">

								  <div class="tab-pane active" id="home">
									<form action="pages/editiorial/save.php" method="post" enctype="multipart/form-data" class="form-horizontal row-fluid">

										<div class="control-group">
											<label class="control-label" for="basicinput">News Title</label>
											<div class="controls">
												<input type="text" name="title" id="basicinput" placeholder="Type something here..." class="span8" required="">
												
											</div>
										</div>

										<div class="control-group">
											<label class="control-label" for="basicinput">Short Blog</label>
											<div class="controls">
												<textarea name="sblog" class="span8" rows="2" required=""></textarea>
												<span class="help-inline">Maximum 2 line</span>
											</div>
										</div>

										<div class="control-group">
											<label class="control-label" for="basicinput">Larg blog</label>
											<div class="controls">
												<textarea name="lblog" class="span8" rows="5" required=""></textarea>
												
											</div>
										</div>

										<div class="control-group">
											<label class="control-label" for="basicinput">Editor name</label>
											<div class="controls">
												<input type="text" name="name" id="basicinput" placeholder="Type something here..." class="span8" required="">
												
											</div>
										</div>

										<div class="control-group">
											<label class="control-label" for="basicinput">image</label>
											<div class="controls">
												<input type="file" name="image" id="basicinput" placeholder="Type something here..." class="span8">
												
											</div>
										</div>

										<div class="control-group">
											<div class="controls">
												<button type="submit" name="submit" class="btn">Submit Form</button>
											</div>
										</div>
									</form>
								  </div>

								  <div class="tab-pane" id="profile">
										<div class="module">
											<div class="module-head">
												<h3>DataTables</h3>
											</div>
											<div class="module-body table">
												<table cellpadding="0" cellspacing="0" border="0" class="datatable-1 table table-bordered table-striped	 display" width="100%">
													<thead>
														<tr>
															<th>id</th>
															<th style="width: 120px;">img</th>
															<th>title</th>
															<th>Short Blog</th>
															<th>Larg Blog</th>
															<th>Editor</th>
															<th>Add Time</th>
															<th>action</th>
														</tr>
													</thead>
													<tbody>
														<?php
														while($data2=mysqli_fetch_assoc($query)){
														?>
														<tr>
															<td><?php echo $data2['id']?></td>
															<td style="width: 120px;">
																<img src="../poster/<?php echo $data2['image']?>" style="width: 120px;">
															</td>
															<td><?php echo $data2['title']?></td>
															<td><?php echo $data2['short_blog']?></td>
															<td><?php echo $data2['larg_blog']?></td>
															<td><?php echo $data2['name']?></td>
															<td><?php echo $data2['add_time']?></td>
															<td>
																<a href="pages/editiorial/delete.php?id=<?php echo $data2['id']?>" class="btn btn-defult">Delete</a>
															</td>
															
															
														</tr>
														<?php }?>
													</tbody>
													
												</table>
											</div>
										</div>
								</div>
								</div>
							</div>

									
							</div>
						</div>
					</div>
								</div>
							</div>
						</div>

						
						
					</div><!--/.content-->
				</div>