<?php
include '../db/db.php';
$sql="SELECT news.*,category.category,sub_category.sub_category FROM news 
	  LEFT JOIN category ON news.cat_id=category.id 
	  LEFT JOIN sub_category ON news.sub_cat_id=sub_category.id";
	  
$query=mysqli_query($db,$sql);
?>