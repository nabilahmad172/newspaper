<?php
session_start();
include '../../../db/db.php';
if(isset($_POST['submit'])){
	$id=$_POST['id'];
	$category=$_POST['category'];
	$subCat=$_POST['subCat'];
	$newsTitle=$_POST['newsTitle'];
	$news=$_POST['news'];
	$publisher=$_POST['publisher'];

	 $imageName=$_FILES['image']['name'];
	 $imageType=$_FILES['image']['type'];

	 if($imageType !='image/jpeg' && $imageType !='image/jpg' && $imageType !='image/png'){
	 	$_SESSION['message']='Please image type insert jpg jpeg or png';
	 	header('location:../../?route=pages/addnews');
	 }else{
	 	$path="../../../poster/$imageName";
  		 $up=move_uploaded_file($_FILES['image']['tmp_name'],$path);

  		if($up > 0){
  			 $sql="UPDATE news SET cat_id=$category,sub_cat_id=$subCat,news_title='$newsTitle',news_details='$news',publisher='$publisher',poster='$imageName',status=1 WHERE id=$id";
  			
  			  $query=mysqli_query($db,$sql);
  			 

  			 if($query > 0){

  			 	$_SESSION['message']='Data update Successfully';
	 			header('location:../../?route=pages/addnews');
  			 }else{
  			 	$_SESSION['message']='Data update not Successfully';
	 			header('location:../../?route=pages/addnews');
  			 }
  		}
	 }

	

}
?>