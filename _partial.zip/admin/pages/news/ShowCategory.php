<?php
include '../db/db.php';
$sql="SELECT * FROM category ";
$cat=mysqli_query($db,$sql);
?>