<?php
session_start();
include '../../../db/db.php';

if(isset($_POST['submit'])){
 $categoryID=$_POST['category'];
 $SubcategoryID=$_POST['subCat'];
 $newsTitle=$_POST['newsTitle'];
 $news=$_POST['news'];
 $publisher=$_POST['publisher'];

  $imageName=$_FILES['image']['name'];
  $imageType=$_FILES['image']['type'];
 
  if($imageType !='image/jpeg' && $imageType !='image/jpg' && $imageType !='image/png'){
  	$_SESSION['message']='Please image type insert jpg jpeg or png';
  	header('location:../../?route=pages/addnews');
  }else{
  	$path="../../../poster/$imageName";
  	$up=move_uploaded_file($_FILES['image']['tmp_name'],$path);
  	if($up > 0){
  		 $sql="INSERT INTO news(cat_id, sub_cat_id, news_title, news_details, publisher, poster,view, status) VALUES ($categoryID,$SubcategoryID,'$newsTitle','$news','$publisher','$imageName',0,1)";
      
  		$query=mysqli_query($db,$sql);
  		if($query > 0){
  			$_SESSION['message']='Data insert Successfuly!';
  			header('location:../../?route=pages/addnews');
  		}else{
  			$_SESSION['message']='Data insert not Successfuly!';
  			header('location:../../?route=pages/addnews');
  		}
  	}
  }
	
}
?>