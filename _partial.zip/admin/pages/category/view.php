<?php
include '../db/db.php';
$sql="SELECT * FROM category";
$select=mysqli_query($db,$sql);

?>