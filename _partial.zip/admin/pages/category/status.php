<?php
session_start();
include '../../../db/db.php';
 $id=$_GET['id'];
 $status=$_GET['status'];

 if($status == 'inactive'){

 	

 	$sql="UPDATE category SET status=0 WHERE id=$id";
 	$up=mysqli_query($db,$sql);

 	if($up > 0){
 		$_SESSION['message']='Data update Successful';
 		header('location:../../index.php?route=pages/category');
 	}else{
 		$_SESSION['message']='Data not update Successful';
 		header('location:../../index.php?route=pages/category');
 	}
 }

 if($status == 'active'){

 	$sql="UPDATE category SET status=1 WHERE id=$id";
 	$up=mysqli_query($db,$sql);

 	if($up > 0){
 		$_SESSION['message']='Data update Successful';
 		header('location:../../index.php?route=pages/category');
 	}else{
 		$_SESSION['message']='Data not update Successful';
 		header('location:../../index.php?route=pages/category');
 	}
 }
?>