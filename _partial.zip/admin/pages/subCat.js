$(document).ready(function(){
	$('#cat').change(function(){
		var value = $(this).val();
		if(value == 0){
			$('#sub_Cat').hide();
		}else{
			$('#sub_Cat').show();
			$.post('pages/news/showSubCat.php',{id:value},function(data){
				$('#sub_Cat').html(data);
			});
		}
	})
})