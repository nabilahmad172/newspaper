<?php 
include 'news/ShowCategory.php';
include 'news/viewCategory.php';
?>

<div class="span9">
					<div class="content">

						<div class="module">
							<div class="module-head">
								<h3>Forms</h3>
								<center>
									<?php
									if(isset($_SESSION['message'])){
										echo $_SESSION['message'];
									}
									unset($_SESSION['message']);
									?>
								</center>
							</div>
							<div class="module-body">

								<ul class="nav nav-tabs" role="tablist">
									<li class="active"><a href="#home" role="tab" data-toggle="tab">Add category</a></li>
									<li><a href="#profile" role="tab" data-toggle="tab">View Category</a></li>
									
								</ul>
								<div class="tab-content">
								<div class="tab-pane active" id="home">
									<form class="form-horizontal row-fluid" action="pages/news/saveNews.php" method="post" enctype="multipart/form-data">

										<div class="control-group">
											<label class="control-label" for="basicinput">Category</label>
											<div class="controls"> 
												<select id="cat" name="category" class="span8">
													<option value="0">Select here..</option>
													
													<?php 
													while ($data=mysqli_fetch_assoc($cat)) {
													
													?>
													<option value="<?php echo $data['id']?>"><?php echo $data['category']?></option>
													<?php }?>
												</select>
											</div>
										</div>

										<div class="control-group">
											<label class="control-label" for="basicinput">Sub Category</label>
											<div class="controls">
												<select id="sub_Cat" name="subCat" data-placeholder="Select here.." class="span8" style="display: none;">
													
												</select>
											</div>
										</div>
										

										<div class="control-group">
											<label class="control-label" for="basicinput">Add news title</label>
											<div class="controls">
												
												<textarea name="newsTitle" placeholder="Add here..." data-original-title="" class="span8 tip"></textarea>
											</div>
										</div>
										<div class="control-group">
											<label class="control-label" for="basicinput">news</label>
											<div class="controls">
												
												<textarea name="news" placeholder="Add here..." data-original-title="" class="span8 tip" cols="50" rows="10"></textarea>
											</div>
										</div>
										<div class="control-group">
											<label class="control-label" for="basicinput">publisher name</label>
											<div class="controls">
												<input name="publisher" type="text" placeholder="Add here..." data-original-title="" class="span8 tip">
											</div>
										</div>
										<div class="control-group">
											<label class="control-label" for="basicinput">Picture</label>
											<div class="controls">
												<input name="image" type="file" class="span8 tip">
											</div>
										</div>

										<div class="control-group">
											<div class="controls">
												<button type="submit" name="submit" class="btn">Submit Form</button>
											</div>
										</div>
									</form>
								</div>
					<div class="tab-pane" id="profile">
						<div class="module">
							<div class="module-head">
								<h3>DataTables</h3>
							</div>
							<div class="module-body table">
								<table cellpadding="0" cellspacing="0" border="0" class="datatable-1 table table-bordered table-striped	 display" width="100%">
									<thead>
										<tr>
											<th>id</th>
											<th style="width: 120px;">img</th>
											<th>Category</th>
											<th>Sub category</th>
											<th>News title</th>
											<th>details</th>
											<th>Adder</th>
											<th>add time</th>
											<th>action</th>
										</tr>
									</thead>
									<tbody>
										<?php
										while($data2=mysqli_fetch_assoc($query)){
										?>
										<tr>
											<td><?php echo $data2['id']?></td>
											<td style="width: 120px;">
												<img src="../poster/<?php echo $data2['poster']?>" style="width: 120px;">
											</td>
											<td><?php echo $data2['category']?></td>
											<td><?php echo $data2['sub_category']?></td>
											<td><?php echo $data2['news_title']?></td>
											<td><?php echo $data2['news_details']?></td>
											<td><?php echo $data2['publisher']?></td>
											<td><?php echo $data2['add_time']?></td>
											<td>
												<?php
													if ($data2['status']==1) {
												?>
													<a href="pages/news/status.php?id=<?php echo $data2['id']?>&&status=inactive" class="btn btn-defult">Active</a>
												<?php }else{?>
													<a href="pages/news/status.php?id=<?php echo $data2['id']?>&&status=active" class="btn btn-danger">Inactive</a>
												<?php }?>
												<a href="?route=pages/editNews&&id=<?php echo $data2['id']?>" class="btn btn-defult">Edit</a>
												<a href="pages/news/delete.php?id=<?php echo $data2['id']?>" class="btn btn-defult">Delete</a>
											</td>
											
										</tr>
										<?php }?>
									</tbody>
									
								</table>
							</div>
						</div>
								</div>
								</div>
							</div>

									
							</div>
						</div>
					</div><!--/.content-->
				</div>

				<script type="text/javascript" src="pages/jquery-3.3.1.min.js"></script>
				<script type="text/javascript" src="pages/subCat.js"></script>