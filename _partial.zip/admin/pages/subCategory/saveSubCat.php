<?php
session_start();
include '../../../db/db.php';
if(isset($_POST['submit'])){
	 $catid=$_POST['cateID'];
	 $subCatname=$_POST['Subcategory'];

	$sql="INSERT INTO sub_category( cat_id, sub_category, status) VALUES ($catid,'$subCatname',1)";
	$insert=mysqli_query($db,$sql);
	if($insert > 0){
		$_SESSION['message']='Data add successfuly';
		header('location:../../?route=pages/subcategory');
	}else{
		$_SESSION['message']='Data add unsuccessfuly';
		header('location:../../?route=pages/subcategory');
	}
}
?>