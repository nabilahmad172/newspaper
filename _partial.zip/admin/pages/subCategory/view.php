<?php
include '../db/db.php';
$sql="SELECT sub_category.*,category.category FROM sub_category LEFT JOIN category ON sub_category.cat_id=category.id";
$show=mysqli_query($db,$sql);

?>