<?php
include '../../db/db.php';
$id=$_GET['id'];
$sql="SELECT * FROM sub_category WHERE id=$id";
$query=mysqli_query($db,$sql);
$fetch=mysqli_fetch_assoc($query);
?>