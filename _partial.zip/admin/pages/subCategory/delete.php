<?php
session_start();
include '../../../db/db.php';
$id=$_GET['id'];
$sql="DELETE FROM sub_category WHERE id=$id";
$delete=mysqli_query($db,$sql);

if($delete > 0){
	$_SESSION['message']='Data delete successfully!';
	header('location:../../?route=pages/subcategory');
}else{
	$_SESSION['message']='Data delete successfully!';
	header('location:../../?route=pages/subcategory');
}
?>