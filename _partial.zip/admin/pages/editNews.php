<?php
include 'news/ShowCategory.php';
include 'news/getNews.php';
?>

<div class="span9">
					<div class="content">

						<div class="module">
							<div class="module-head">
								<h3>Forms</h3>
							</div>
							<div class="module-body">
								<form class="form-horizontal row-fluid" action="pages/news/UpdateNews.php" method="post" enctype="multipart/form-data">

										<div class="control-group">
											<input type="hidden" name="id" value="<?php echo $fetch['id']?>">
											<label class="control-label" for="basicinput">Category</label>
											<div class="controls"> 
												<select id="cat" name="category" class="span8">
													<option value="0">Select here..</option>
													
													<?php 
													while ($data=mysqli_fetch_assoc($cat)) {
													
													?>
													<option value="<?php echo $data['id']?>"><?php echo $data['category']?></option>
													<?php }?>
												</select>
											</div>
										</div>

										<div class="control-group">
											<label class="control-label" for="basicinput">Sub Category</label>
											<div class="controls">
												<select id="sub_Cat" name="subCat" data-placeholder="Select here.." class="span8" style="display: none;">
													
												</select>
											</div>
										</div>
										

										<div class="control-group">
											<label class="control-label" for="basicinput">Add news title</label>
											<div class="controls">
												
												<textarea name="newsTitle" placeholder="Add here..." data-original-title="" class="span8 tip"><?php echo $fetch['news_title']?></textarea>
											</div>
										</div>
										<div class="control-group">
											<label class="control-label" for="basicinput">news</label>
											<div class="controls">
												
												<textarea name="news" placeholder="Add here..." data-original-title="" class="span8 tip" cols="50" rows="10"><?php echo $fetch['news_details']?></textarea>
											</div>
										</div>
										<div class="control-group">
											<label class="control-label" for="basicinput">publisher name</label>
											<div class="controls">
												<input name="publisher" type="text" placeholder="Add here..." data-original-title="" class="span8 tip" value="<?php echo $fetch['publisher']?>">
											</div>
										</div>
										<div class="control-group">
											<center><img src="../poster/<?php echo $fetch['poster']?>" height="150" width="150"></center>
										</div>
										<div class="control-group">
											<label class="control-label" for="basicinput">Picture</label>
											<div class="controls">
												<input name="image" type="file" class="span8 tip">
											</div>
										</div>

										<div class="control-group">
											<div class="controls">
												<center><button type="submit" name="submit" class="btn" style="height: 80px; width: 400px; border: 1px solid #ccc;">Update</button></center>
											</div>
										</div>
									</form>
							</div>
						</div>

						
						
					</div><!--/.content-->
				</div>

				<script type="text/javascript" src="pages/jquery-3.3.1.min.js"></script>
				<script type="text/javascript" src="pages/subCat.js"></script>